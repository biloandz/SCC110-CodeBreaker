
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import static java.awt.Color.*;

class GameBoard extends JFrame {
  static ColorCode colorCode = new ColorCode();
  static JFrame frame;
  static JPanel guessMenu = new JPanel(new FlowLayout());
  static JTable board;

  static int row_num = 0;
  static int col_num = 0;

  static List<Color> returnList = new ArrayList<>();

  static JLabel color_label_1= new JLabel();
  static JLabel color_label_2= new JLabel();
  static JLabel color_label_3= new JLabel();
  static JLabel color_label_4= new JLabel();
  static JLabel color_label_5= new JLabel();
  static JLabel color_label_6= new JLabel();
  static JLabel color_label_7= new JLabel();

  static JLabel empty= new JLabel();
  static JLabel empty_4= new JLabel();

  static List<Color> baseColors = Arrays.asList(new Color[]{Color.blue,
          Color.green,
          Color.orange, Color.red, Color.yellow,
          Color.gray,
          Color.white});


  static Object[] colorIcons = {
    new ImageIcon("Colour_4.png"),
    new ImageIcon("Colour_3.png"),
    new ImageIcon("Colour_1.png"),
    new ImageIcon("Colour_0.png"),
    new ImageIcon("Colour_2.png"),
    new ImageIcon("Colour_5.png"),
    new ImageIcon("Colour_6.png")
  };







  static DefaultTableModel boardModel;



  public static void checkTheGuess(){


    if (ColorCode.currentGameState == ColorCode.GameState.PLAYING) {
      CheckMatch matches = colorCode.guess(returnList);

      List<Object> tempList = new ArrayList<>();

      for (Color color : returnList) {
        tempList.add(colorIcons[baseColors.indexOf(color)]);
      }

      int black = matches.positionalMatches;
      int gray = matches.matches;
      int wrong = 4-black;
      wrong = wrong-gray ;
      String name = black+"c"+"_"+gray+"wp"+"_"+wrong+"w"+".png";

      tempList.add(new ImageIcon(""+name));


      for (int index = 0; index < 5; index++) {
        boardModel.setValueAt(tempList.get(index), colorCode.turnNumber - 1, index);
      }

      if(black==4){
        JOptionPane.showMessageDialog(null,"You have guessed it correctly!");
        System.exit(0);
      }

    }
    boardModel.fireTableDataChanged();
  }


  public static void main(String[] args) {


    color_label_1.setIcon(new Picture("Colour_0.png"));
    color_label_2.setIcon(new Picture("Colour_1.png"));
    color_label_3.setIcon(new Picture("Colour_2.png"));
    color_label_4.setIcon(new Picture("Colour_3.png"));
    color_label_5.setIcon(new Picture("Colour_4.png"));
    color_label_6.setIcon(new Picture("Colour_5.png"));
    color_label_7.setIcon(new Picture("Colour_6.png"));
    empty.setIcon(new Picture("empty.png"));

    empty_4.setIcon(new Picture("empty_4.png"));

    frame = new JFrame("Color Breaker");
       boardModel = new DefaultTableModel(7, 5);
    board = new JTable(boardModel) {
      public Class getColumnClass(int column) {
        return (column == 7) ? Object.class : Icon.class;
      }
      public boolean isCellEditable(int row, int column) {
        return false;
      }
    };
    board.setBackground(new Color(107, 73, 34));

    board.setRowHeight(100);

    
    
    board.getColumnModel().getColumn(0).setPreferredWidth(2);
    board.getColumnModel().getColumn(1).setPreferredWidth(2);
    board.getColumnModel().getColumn(2).setPreferredWidth(2);
    board.getColumnModel().getColumn(3).setPreferredWidth(2);
    board.getColumnModel().getColumn(4).setPreferredWidth(2);

    for (int i = 0; i < 7; i++) {
      for (int j = 0; j < 5; j++) {
        if(j == 4){
          boardModel.setValueAt(empty_4.getIcon(),i, j);
        }else{
          boardModel.setValueAt(empty.getIcon(),i, j);
        }
      }
    }







    color_label_1.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e)
      {


          returnList.add(RED);
          boardModel.setValueAt(color_label_1.getIcon(), row_num, col_num);
          if(returnList.size()==4){
            checkTheGuess();
            returnList = new ArrayList<>();
            col_num=-1;
            row_num++;
            if(row_num == 7){
              JOptionPane.showMessageDialog(null, "You are out of attempts!");

              System.exit(0);
            }

          }
        col_num++;

      }


      });


    color_label_2.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent e)
      {


          returnList.add(ORANGE);
          boardModel.setValueAt(color_label_2.getIcon(), row_num, col_num);
          if(returnList.size()==4){
            checkTheGuess();
            returnList = new ArrayList<>();
            col_num=-1;
            row_num++;
            if(row_num == 7){
              JOptionPane.showMessageDialog(null, "You are out of attempts!");
              System.exit(0);
            }

            }
        col_num++;



      }
    });

    color_label_3.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent e)
      {
        returnList.add(yellow);
          boardModel.setValueAt(color_label_3.getIcon(), row_num, col_num);
          if(returnList.size()==4) {
            checkTheGuess();
            returnList = new ArrayList<>();
            col_num = -1;
            row_num++;
            if (row_num == 7) {
              JOptionPane.showMessageDialog(null, "You are out of attempts!");
              System.exit(0);
            }
          }

            col_num++;


        }
      }
    );
    color_label_4.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent e)
      {



          returnList.add(green);
          boardModel.setValueAt(color_label_4.getIcon(), row_num, col_num);
          if(returnList.size()==4){
            checkTheGuess();
            returnList = new ArrayList<>();
            col_num=-1;
            row_num++;
            if(row_num == 7){
              JOptionPane.showMessageDialog(null, "You are out of attempts!");
              System.exit(0);
            }

          }
        col_num++;

      }

    });


    color_label_5.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent e)
      {

  returnList.add(blue);
          boardModel.setValueAt(color_label_5.getIcon(), row_num, col_num);

          if(returnList.size()==4){
            checkTheGuess();
            returnList = new ArrayList<>();
            col_num=-1;
            row_num++;
            if(row_num == 7){
              JOptionPane.showMessageDialog(null, "You are out of attempts!");
              System.exit(0);
            }

          }
        col_num++;

      }

    });



    color_label_6.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent e)
      {


        returnList.add(Color.gray);
          boardModel.setValueAt(color_label_6.getIcon(), row_num, col_num);

          if(returnList.size()==4){
            checkTheGuess();
            returnList = new ArrayList<>();
            col_num=-1;
            row_num++;
            if(row_num == 7){
              JOptionPane.showMessageDialog(null, "You are out of attempts!");
              System.exit(0);
            }

          }
        col_num++;

      }
    });


    color_label_7.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent e)
      {




          returnList.add(Color.white);

          boardModel.setValueAt(color_label_7.getIcon(), row_num, col_num);
          if(returnList.size()==4){
            checkTheGuess();
            returnList = new ArrayList<>();
            col_num=-1;
            row_num++;
            if(row_num == 7){
              JOptionPane.showMessageDialog(null, "You are out of attempts!");
              System.exit(0);
            }

          }
        col_num++;


      }


    });


    guessMenu.setBackground(new Color(107, 73, 34));
    guessMenu.add(color_label_1);
    guessMenu.add(color_label_2);
    guessMenu.add(color_label_3);
    guessMenu.add(color_label_4);
    guessMenu.add(color_label_5);
    guessMenu.add(color_label_6);
    guessMenu.add(color_label_7);



    Container pane = frame.getContentPane();
    pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
    frame.add(board);
    frame.add(guessMenu);
    frame.setLocationRelativeTo(null);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(700, 850);
    frame.setVisible(true);
  }
}