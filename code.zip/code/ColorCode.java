

import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

import static java.util.Collections.shuffle;

public class ColorCode {
  public List<Color> selectedColors;
  public int turnNumber;
  public enum GameState {PLAYING, WON, LOST}
  public static GameState currentGameState;

  List<Color> shuffleSelectedColors() {
    List<Color> fullColors = new ArrayList<>();

    fullColors.addAll(Arrays.asList(Color.blue, Color.green,  Color.orange, Color.red, Color.yellow,  Color.getColor("indigo"),
            Color.getColor("violet")));
    shuffle(fullColors);

    return fullColors.subList(0, 4);
  }

  public ColorCode() {
    selectedColors = shuffleSelectedColors();
    currentGameState = GameState.PLAYING;
    turnNumber = 0;
  }



  public CheckMatch guess(List<Color> guessColors) {
    turnNumber++;
    CheckMatch checkMatch = matchGuess(guessColors);
    gameStateCheck(checkMatch.positionalMatches);

    return checkMatch;
  }

  public CheckMatch matchGuess(List<Color> guessColors) {
    int matches = 0;
    int positionalMatches = 0;
    int noMatches = 0;
    int index = 0;

    for (Color color: selectedColors) {
      if(guessColors.contains(color)) {
        if (selectedColors.get(index) == guessColors.get(index)) {
          positionalMatches++;
        }
        else {
          matches++;
        }
      }
      else {
        noMatches++;
      }
      index++;
    }

    return new CheckMatch(noMatches, matches, positionalMatches);
  }

  public void gameStateCheck(int positionalMatches) {
    gameOverCheck();

    if(positionalMatches == 6) {
      currentGameState = GameState.WON;
    }
    else if(turnNumber >= 20) {
      currentGameState = GameState.LOST;
    }
  }

  public void gameOverCheck() {
    if(currentGameState != GameState.PLAYING) {
      throw new ArithmeticException("Game already over.");
    }
  }


}