

public class CheckMatch {
  public final int noMatches;
  public final int matches;
  public final int positionalMatches;

  public CheckMatch(int none, int match, int positional) {
    noMatches = none;
    matches = match;
    positionalMatches = positional;
  }
}
